'''
(Minimal) Starter code for A3
'''
import argparse
import json

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--projects_in',
                        type=str,
                        default='kickstarter_projects.jsonl')
    return parser.parse_args()


def load_corpus_jsonlist(fname, limit=None):
    all_projects = []
    with open(fname) as f:
        for line in f:
            project = json.loads(line.strip())
            all_projects.append(project)
            if limit and len(all_projects) == limit:
                break
    print('Loaded {} projects'.format(len(all_projects)))
    return all_projects


def main():
    args = parse_args()
    all_projects = load_corpus_jsonlist(args.projects_in, limit=5000)

    ### Question 0: Characteristics of the first project

    # TODO
    
    ### Question 1: Creating the tfidf matrix

    # TODO

    ### Question 2: The Art Of Sloth Survival
    
    # This project is called: "The Art of Sloth Survival"
    # https://www.kickstarter.com/projects/415722412/the-art-of-sloth-survival
    print(all_projects[134]['title'])

    # TODO
    
    ### Question 3: Truncated SVD with 500D + scree plot to select dimension

    # TODO

    ### Question 4: Truncated SVD with the selected dimension and TSNE

    # TODO

if __name__ == '__main__':
    main()
