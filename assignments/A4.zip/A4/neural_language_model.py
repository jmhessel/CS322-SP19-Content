import argparse
import nltk
import collections
import math
import tqdm
import numpy as np
import keras

from gensim.models.keyedvectors import KeyedVectors

from sklearn.preprocessing import normalize

global _TOKENIZER
_TOKENIZER = nltk.tokenize.casual.TweetTokenizer(
    preserve_case=False)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--train_tokens',
                        default='movies_train.toks',
                        help='path to training tokens file')
    parser.add_argument('--val_tokens',
                        default='movies_val.toks',
                        help='path to validation tokens file')
    parser.add_argument('--history',
                        default=4,
                        type=int,
                        help='what is the lookback history?')
    parser.add_argument('--max_vocab_size',
                        default=1500,
                        type=int,
                        help='vocab consists of at most this many of the most-common words')
    parser.add_argument('--seed',
                        default=1,
                        type=int,
                        help='Seed for the RNG.')
    parser.add_argument('--word2vec_init',
                        default=0,
                        type=int,
                        help='Should we initalize the embedding layer with word2vec weights?')
    return parser.parse_args()


def tokenize(string):
    '''Given a string, consisting of potentially many sentences, returns
    a lower-cased, tokenized version of that string.
    '''
    global _TOKENIZER
    return _TOKENIZER.tokenize(string)


def load_lines_corpus(fname, limit=None):
    '''Loads the corpus to a list of token lists, ignoring blank lines.'''
    lines = []
    with open(fname) as f:
        for line in tqdm.tqdm(f):
            if len(line.strip()) == 0: continue
            lines.append(tokenize(line))
            if limit and len(lines) == limit: break
    print('Loaded {} lines.'.format(len(lines)))
    return lines


def count_unigrams(token_lists):
    '''Given a list of token lists, return a dictionary mapping word types
    to their corpus-level counts.
    '''
    word2count = {}
    for token_list in token_lists:
        for w in token_list:
            if w not in word2count:
                word2count[w] = 0
            word2count[w] += 1
    return word2count
    

def make_all_contexts(token_lists, vocabulary, history, shuffle=True):
    '''
    Input:
      token_lists: list of lists of tokens.
      vocabulary: a dictionary mapping words to indices in the vocabulary
      history: the amount of tokens you're looking back to. you'll use this
               when adding in padding tokens to the front of the list. you should
               also add a padding token to the end.
      shuffle: whether to shuffle the context, output pairs
    output:
      a list of [(context, target pairs)]. Here are some shuffled sample
      outputs of my solution when args.history=4.

    [(('script', 'for', '<UNK>', 'but'), 'when'),
     (('enough', ',', 'a', '<UNK>'), '<UNK>'),
     (('<s>', '<s>', '<s>', '<s>'), i),
     (('is', 'often', 'difficult', 'to'), 'appreciate'),
     (('sets', 'and', 'the', 'pointless'), 'many'),]
    '''
    raise NotImplementedError('TODO')


def generate_context_batches(all_contexts, word2idx, batch_size=128):
    '''This is a python generator, i.e., it should use the yeild statement
    instead of a return statement. Check out the keras documentation
    for fit_generator at https://keras.io/models/sequential/. If generators
    are new to you, you can learn more about them here:
    https://wiki.python.org/moin/Generators
    
    In short --- you'll want to make a generator that loops forever,
    and consistently yeilds 2 numpy arrays, X and y (i.e., you'll have a
    statement similar to "yeild X, y" in your code).

    X and y have the following characteristics:

    X is a numpy array of shape (batch_size, args.history) where each
    row of X is a representation of the context words preceeding the
    target row in the particular example. Here is a sample X my
    generator yeilds when I set batch_size to 5, where each row
    represents a different context:

    [[ 663  611   37    9]
     [  39   35  195   14]
     [ 195   14   39  944]
     [ 944  663  809    6]
     [ 791  931 1302  499]]

    the first row of this matrix indicates that the context words preceeding
    my target in the first example are 663 then 611 then 37 then 9.

    y is a numpy array of shape (batch_size, len(word2idx)), where
    each row is a one-hot indicator of the target vocabulary item. In
    a simple case, consider a vocab size of 8. The following array
    would be a valid y for a batch_size of 5:

    [[1. 0. 0. 0. 0. 0. 0. 0.]
     [1. 0. 0. 0. 0. 0. 0. 0.]
     [0. 0. 0. 1. 0. 0. 0. 0.]
     [0. 0. 0. 0. 1. 0. 0. 0.]
     [0. 0. 0. 0. 0. 0. 0. 1.]]

    the fact that y_{1,0} is 1 indicates that the word following

    [ 39 35 195 14]
    (from the example X above)
    
    is the word at vocabulary index 0. Of course, your vocabulary will
    normally be much larger than 8, so the number of columns of y will
    generally be quite large.

    '''
    raise NotImplementedError('TODO')

                
def compute_perplexity(token_list, model, history, word2idx, epsilon=1E-12):
    '''Given a model that maps contexts --> P(w | context) for each word,
    compute the perplexity of the input token list according to the
    model. My function generates contexts from the input token list by
    making a call to make_all_contexts with shuffle=False. Then, I
    convert the contexts into the numpy array X that the model
    expects, as described in the documentation for
    generate_context_batches. Then, I call model.predict to get the
    probability distribution estimates. Then, I add epsilon to each
    for numerical stability, and re-normalize to a true probability
    distribution. Finally --- I compute perplexity from the summed log
    conditionals, and return it!
    '''
    raise NotImplementedError('TODO')

def get_word2vec_init(word2idx, limit=100000):
    '''Given a dictionary mapping from words to indices, return a
    len(word2idx) by 300 dimensional matrix M where M[word2idx[w],:]
    corresponds to the word embedding from GoogleNews for word w. If a
    word is not in the GoogleNews word embedding model, the
    corresponding row should be all zeros.

    limit corresponds to the number of words that we load in gensim,
    i.e., when calling load_word2vec_format, pass the limit parameter
    on.
    '''
    raise NotImplementedError('TODO')


def main():
    args = parse_args()
    np.random.seed(args.seed)
    
    train_lines, val_lines = map(load_lines_corpus,
                                 [args.train_tokens,
                                  args.val_tokens])

    # count the unigrams
    unigram_counts = count_unigrams(train_lines)
    valid_vocab = set(['<UNK>', '<s>', '</s>'])
    for u, c in sorted(unigram_counts.items(), key=lambda x: -x[1]):
        valid_vocab.add(u)
        if len(valid_vocab) >= args.max_vocab_size:
            break

    print('Of the original {} types, {} are in the final vocab'.format(
        len(unigram_counts),
        len(valid_vocab)))

    # make a mapping of {vocabulary -> index}
    word2idx = {v:idx for idx, v in enumerate(sorted(list(valid_vocab)))}
    
    training_contexts = make_all_contexts(train_lines, valid_vocab, args.history)
    validation_contexts = make_all_contexts(val_lines, valid_vocab, args.history)

    training_generator = generate_context_batches(training_contexts,
                                                  word2idx)
    validation_generator = generate_context_batches(validation_contexts,
                                                    word2idx)

    ### Make the model! ###
    my_model = keras.models.Sequential()

    #the model.add function should be useful here similarly --- the
    #documentation available at keras.io should be helpful!!
    
    raise NotImplementedError('TODO')

    for idx in range(30):
        my_model.fit_generator(training_generator,
                               steps_per_epoch=5000,
                               epochs=1,
                               validation_data=validation_generator,
                               validation_steps=500)
        all_perp = []
        for v in tqdm.tqdm(val_lines):
            perp = compute_perplexity(v,
                                      my_model,
                                      args.history,
                                      word2idx)
            all_perp.append(perp)
        print('Current perplexity {:.3f}'.format(np.mean(all_perp)))
    print(all_perp)


if __name__ == '__main__':
    main()
